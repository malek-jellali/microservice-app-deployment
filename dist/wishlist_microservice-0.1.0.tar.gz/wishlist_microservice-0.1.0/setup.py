from setuptools import setup, find_packages

setup(
    name="wishlist_microservice",
    version="0.1.0",
    packages=find_packages(),  # Automatically finds packages in the directory
)
